---
name: gys-old-to-new-screen
description: 公営企業会計システム刷新プロジェクト (ぎょうせい/GYS × ファンリード/FL) の旧システム画面・帳票を新システムUIデザインガイドラインv1.2準拠の新画面に置換する5フェーズ標準ワークフロー。Box旧画面.xlsx → 項目抽出 → DS突合 → HTMLプロト(frontend-design) → Figma還元(prototype-to-figma) → 実装引き継ぎ。「GYS画面を新システムに置き換えて」「対前年度比較表を新画面に」「旧画面の新システム化」「STD系画面の新版作成」「予算査定一覧 新画面」「BFP系帳票を新DS」等のキーワードで必ず発動。新規画面1枚から量産まで対応。
metadata:
  type: workflow
  project: GYS (公営企業会計システム新版)
  version: 1.0
  baseline-sample: STD3290 対前年度比較表 / BFP9100 予算査定一覧表(科目別)
---

# GYS 旧→新画面化 標準ワークフロー

このスキルは公営企業会計システム (ぎょうせい/GYS × ファンリード/FL) で、**旧システム画面を新システムUIデザインガイドライン v1.2 準拠で置換する5フェーズワークフロー** を実行する。

## 必須リファレンス (起動時に読む)

| 種別 | パス |
|---|---|
| ハンドオフ詳細 | `~/Desktop/GYS/20260519_GYS旧→新画面化_ワークフローハンドオフ.md` |
| サンプル HTML | `~/Desktop/GYS/prototype-condition-screen/index_v0.2.html` |
| サンプル Figma | https://www.figma.com/design/WJV7kypIvgYuwLemNcEJPE |
| サンプル Phase別資料 | `~/Desktop/GYS/20260519_*.md` |
| shared-components | `/Users/apple/Desktop-backup/projects/gys-yosanhensei/gyousei-shared-components/src/components/` |
| デザインガイドライン (Box) | ID `2176447218566` |
| Yosanhensei-Frontend | `/Users/apple/Desktop-backup/projects/gys-yosanhensei/Yosanhensei-Frontend/` |

**最初にハンドオフ資料を Read してから着手すること。**

## 5フェーズ概要

```
[Box旧画面.xlsx] → ①抽出 → ②DS突合 → ③プロトHTML → ④Figma還元 → ⑤実装引き継ぎ
```

### Phase 1: 旧画面項目抽出
- 入力: Box ファイルID (帳表仕様確認書 .xlsx)
- ツール: Box MCP (`get_file_details`, `get_file_content`, `get_preview_page`)
- 画像取得失敗時: ユーザーに `~/Downloads` へダウンロード依頼 → `unzip -o <xlsx> 'xl/media/*'`
- 出力: `~/Desktop/GYS/YYYYMMDD_{画面ID}_{画面名}_旧システム抽出.md`

### Phase 2: デザインガイドライン照合
- 入力: Phase 1抽出物 + ガイドライン (Box `2176447218566`) + shared-components ls
- ツール: Box MCP `get_file_content` + Read `tailwind.config.js` + Bash `ls`
- 出力: `~/Desktop/GYS/YYYYMMDD_{画面ID}_旧→新DS突合表.md`
- 必ず立てる: オープン質問 L1-L5 (レイアウト/スピナー/ラジオ意味/コード+名称/依存ロジック)

### Phase 3: HTMLプロトタイプ
- 入力: Phase 1/2 Markdown
- スキル併用: `frontend-design`
- 形式: 単一HTML (Tailwind CDN + Noto Sans JP via Google Fonts)
- 命名: `~/Desktop/GYS/prototype-{画面名}/index_v0.{N}.html`
- 編集時は `cp v0.N → v0.N+1` で履歴管理してから Edit
- 🔴 **4点セット必須** (Header / Sidebar / Footer / Breadcrumb) — 実装側 import 構造に合わせる

### Phase 4: Figma還元
- スキル併用: `prototype-to-figma`, `figma:figma-create-new-file`, `figma:figma-use`
- planKey: `team::1316584710901923109`
- 7-9 `use_figma` call 分割 (Sidebar込みで増加)
- 各 call 先頭でフォント load 必須
- 🔴 **4点セット必須** (Header / Sidebar / Footer / Breadcrumb)

### 🔴 必須レイアウト4点セット (島村さんFB 2026-05-19反映)

実装側コードで以下が必ず import される:
```jsx
import Header from '../../components/Header';
import Sidebar from '../../components/Sidebar';
import Footer from '../../components/Footer';
import Breadcrumb from '../../components/Breadcrumb';
```

Figma/HTMLプロトの構造:
```
Header (full-width 1366px, 72h)
├─ Sidebar (280w固定, menu-bg #F1F9FF) │ Main area (1086w)
│   - 15メニュー項目                    │  ├─ Breadcrumb
│   - 現在地アクティブ                  │  ├─ Title + ID badge
│   - サブメニュー展開                  │  ├─ Tab
│                                       │  └─ Content
Footer (full-width 1366px)
```

### Phase 5: 実装引き継ぎ
- shared-components import 一覧
- 新規追加候補コンポ (SectionCard / StepperWithUnit / 2カラム比較 等)
- 安部・石倉・大塚さんへ Markdown引き渡し

## 共通リファレンス値 (絶対遵守)

### カラートークン (gyousei-shared-components/tailwind.config.js より)

| トークン | 値 | 用途 |
|---|---|---|
| primary | `#2295F9` | メインアクセント |
| primary-light | `#DBEBF5` | ヘッダー背景・アクションボタン |
| primary-dark | `#1B6DB4` | ボーダー・フォーカス状態 |
| border | `#cad2d9` | shared-components 共通ボーダー |
| bg-input | `#f5f7fa` | 入力エリア (§4.1.1) |
| bg-unit | `#EEEEEE` | InputWithUnit 単位部分 |
| bg-readonly | `#F8F7F7` | DualInputField readonly |
| notice-bg | `#D3EEFF` | テーブル content-bg / 通知バー |
| menu-bg | `#F1F9FF` | メニュー背景 |

### フォント (§3.1.3)
- **Noto Sans JP** (Regular 400/Medium 500/Bold 700/Black 900)
- サイズ: 28px=タイトル / 16-20px=小見出し / 13-14px=本文 / 10px=メニュー補助

### 画面基準
- 解像度: 1366×768 (§2.2)
- ボタン高: 大46/中36/小26 (§3.2.17)
- 金額: 桁カンマ + 単位「円」+ 右揃え (§3.2.8)
- 入力エリア背景: グレー `#f5f7fa` (§4.1.1)

### 命名規則 (§3.1.5 用語集)
| 旧 | 新 | 理由 |
|---|---|---|
| 終了ボタン | **キャンセルボタン** | 用語集に「終了」未定義、「キャンセル」が該当 |
| 閉じるボタン | **×ボタン** | ボタン名では使わない |
| 「印刷」 | そのまま (PDF表示の意) | ✅ |
| 「出力」 | そのまま (ローカルDL の意) | ✅ |
| 「クリア」 | そのまま | ✅ |

### shared-components 主要コンポ (30+件)

直接 import 可能:
```
header, footer, breadcrumb, heading, button (3階層),
input, select, checkbox, radio, alert,
input-with-unit, dual-input-field,
amount-field, budget-field, date-field, date-range-field,
form, form-field, form-label-with-required,
card, badge, dialog, modal, dropdown-menu,
collapsible-section, debtor-search-dialog,
container, empty-state, error-boundary
```

shared-components 未収載 (新規追加候補):
- SectionCard (gray bg + section title)
- StepperWithUnit (input + ▲▼ + unit)
- A列/B列 2カラム比較設定パターン

### Ignite UI for React (Yosanhensei-Frontend のみ採用)

`@infragistics/igniteui-react-{core,grids,inputs,layouts}` v19.5.2

| プロト | Ignite UI |
|---|---|
| `.gys-input` | `IgrInput` |
| `.gys-select` | `IgrSelect` / `IgrCombo` |
| `.gys-stepper` | `IgrNumberInput` |
| `<input type="radio">` | `IgrRadioGroup` + `IgrRadio` |
| `.gys-btn-main` | `IgrButton variant="contained" color="primary"` |

**まず shared-components の既存コンポを使う**。Ignite UI は補完用。

## Box ファイルID

| 用途 | Box ID |
|---|---|
| デザインガイドライン | `2176447218566` |
| 帳票仕様確認設計書フォルダ | `372679775768` |
| サンプル: 予算査定一覧科目別 | `2183630001029` |

## オープン質問テンプレート (L1-L5)

Phase 2-3 で必ず立てる:

- **L1**: A列/B列のような並列レイアウト = どのパターン？ (2カラム並列/タブ/アコーディオン/テーブル風)
- **L2**: スピナー (旧Windows風 ▲▼) を新DSでどう対応？ (StepperWithUnit / IgrNumberInput / Select代替)
- **L3**: ラジオ+数値入力の組み合わせの意味 (業務側確認)
- **L4**: コード+名称ペアの命名/採用 (DualInputField)
- **L5**: 動的依存ロジック (grayout等) の再現方針 (動的/非動的/別UI)

## 量産時の注意点

1. 同時並行 **3画面まで** (Figma MCPレート + context窓)
2. DS突合表は **共有Drive一元管理**
3. L3/L5系 オープン質問は **画面横断で集約** してから業務側へ
4. Figma は **GYS共有プロジェクトフォルダ** に保存
5. プロトHTMLは **v0.1, v0.2... 命名 + cp してから Edit**
6. 命名変更 (終了→キャンセル等) は **画面横断で同じ判断**

## トラブルシューティング

| 症状 | 対処 |
|---|---|
| Excel image取れない | ローカルDL + `unzip xl/media/*` |
| `Cannot use unloaded font` | 各 use_figma call 先頭で `loadFontAsync` Promise.all |
| `layoutSizingHorizontal = 'FILL'` エラー | appendChild 後に設定 |
| Figma色がおかしい | 0-1 range (parseInt/255) |
| node.annotations 1個しか付かない | 配列に複数渡せばOK |

## 起動時の確認事項

ユーザーから「{画面名} を新システム化」「STD/BFP系を新画面に」「対前年度比較表」等の依頼を受けたら、以下を先に確認:

1. **対象画面のBox file ID** (or URL)
2. **どこから着手か** (Phase 1全部 or Phase Nから)
3. **業務確認の窓口** (島村さん固定、特定なら指定)
4. **緊急度・期限**
5. **既に類似画面の DS突合表があるか** (~/Desktop/GYS/ 配下確認)

## 関連スキル (併用前提)

| スキル | 用途 | Phase |
|---|---|---|
| `frontend-design` | HTMLプロト生成 | Phase 3 |
| `prototype-to-figma` | Figma還元 | Phase 4 |
| `figma:figma-create-new-file` | 新規Figma作成 (MANDATORY for create_new_file) | Phase 4 |
| `figma:figma-use` | use_figma JS実行 (MANDATORY for use_figma) | Phase 4 |

## ファイル命名規約

```
~/Desktop/GYS/
├── YYYYMMDD_{画面ID}_{画面名}_旧システム抽出.md     ← Phase 1
├── YYYYMMDD_{画面ID}_旧→新DS突合表.md            ← Phase 2
├── prototype-{画面名}/
│   ├── index_v0.1.html                          ← Phase 3 初版
│   ├── index_v0.2.html                          ← Phase 3 改訂版
│   └── index_v0.N.html
├── YYYYMMDD_{画面名}_新システム化_レビュー依頼_{業務担当}.md  ← Phase 4後
└── YYYYMMDD_{画面名}_実装引き継ぎ_{開発担当}.md            ← Phase 5
```

## 担当者一覧 (2026-05-19時点)

| 役割 | 氏名 | 領域 |
|---|---|---|
| プロジェクトリード | 池田克彦 (アップルリード東京) | 全体 |
| 業務 | 島村さん | 帳票仕様・業務観点 |
| 業務 (帳票専門) | 枇杷木さん | 帳票出力フォーマット |
| 設計リード | 安部さん・石倉さん (ファンリード) | 実装難度・DS方針 |
| 実装 | 大塚さん (ファンリード, 石倉配下) | shared-components実装 |
| デザインガイドライン作者 | 入江由佳さん (ファンリード) | UIデザイン v1.2 |
| 帳票仕様書作者 | 杉山拓也さん (ファンリード) | 帳表仕様確認設計書 |

## 改訂履歴

| 版 | 日付 | 改訂者 | 内容 |
|---|---|---|---|
| 1.0 | 2026-05-19 | 池田 + Claude (Opus 4.7) | 初版。STD3290 サンプル完成を機に量産用標準化 |
