# 旧→新画面 HTML化キット v1（共有用）

旧システム画面・帳票（Box仕様書 / 画面スクショ）→ **新システムUIデザインガイドライン v1.2 準拠の HTMLプロトタイプ** 変換ワークフロー一式。
Figma還元・実装引き継ぎまでを 5フェーズで標準化したもの。

> 姉妹キット：**`共有_帳票画面ワイヤー化キット_v1`**（画像 → PPTワイヤー .pptx）。
> 「開発に渡す pptx が欲しい」ならそちら、「動く HTML プロトが欲しい」なら本キット。

## まず読む
- **`ハンドオフ_GYS旧→新画面化ワークフロー.md`** … 実作業のハンドオフ資料（.xlsx 版も同梱）。
- `SKILL_リファレンス.md` … 詳細リファレンス（5フェーズ手順・共通値・命名規則・担当・量産注意点・トラブルシューティング）。

## 5フェーズ

```
[Box旧画面.xlsx / 画面スクショ]
   → ①項目抽出 → ②DS突合 → ③HTMLプロト → ④Figma還元 → ⑤実装引き継ぎ
```

| Phase | 内容 | 出力 |
|---|---|---|
| 1 | 旧画面項目抽出（Box MCP／画像取得失敗時は `unzip -o <xlsx> 'xl/media/*'`） | `YYYYMMDD_{画面ID}_{画面名}_旧システム抽出.md` |
| 2 | デザインガイドライン照合（Box `2176447218566`）＋ オープン質問 L1-L5 | `YYYYMMDD_{画面ID}_旧→新DS突合表.md` |
| 3 | HTMLプロト生成（`frontend-design` 併用／単一HTML + Tailwind CDN + Noto Sans JP） | `prototype-{画面名}/index_v0.{N}.html` |
| 4 | Figma還元（`prototype-to-figma`／`figma:figma-use`） | Figmaファイル + レビュー依頼md |
| 5 | 実装引き継ぎ（shared-components import一覧・新規コンポ候補） | 実装引き継ぎmd |

## 構成

```
共有_旧→新画面HTML化キット_v1/
├── README.md                                  ← これ
├── ハンドオフ_GYS旧→新画面化ワークフロー.md   ← まずこれ（.xlsx 版も同梱）
├── ハンドオフ_GYS旧→新画面化ワークフロー.xlsx
├── SKILL_リファレンス.md                       ← 詳細リファレンス
├── reference/
│   ├── tailwind.config.js                     ← カラートークンの正本（gyousei-shared-components）
│   └── shared-components一覧.txt              ← 直接 import 可能なコンポ一覧
└── samples/
    ├── 条件選択画面/                           ← BFP9100 予算査定一覧表(科目別)／A列・B列 2カラム比較
    │   ├── index_v0.1〜v0.4.html              ← Phase 3 成果物（v0.4 が最新）
    │   └── docs/ (Phase1 抽出 / Phase2 DS突合 / Phase4 レビュー依頼)
    └── DPD1550_固定資産明細表/                 ← 部門・施設・地区別固定資産明細表作成
        ├── index_v0.1.html
        └── DPD1550_Prototype.fig              ← Phase 4 Figma還元の成果物
```

## クイックスタート

```bash
# サンプルHTMLをブラウザで確認（最新版）
open samples/条件選択画面/index_v0.4.html
```

新規画面に着手するときは Claude Code で:

```
/gys-old-to-new-screen     # または「{画面名} を新システム化して」
```

着手前に以下を決めておくと速い:
1. 対象画面の Box file ID（or URL）
2. Phase 1 から全部か、途中の Phase から入るか
3. 業務確認の窓口（既定＝島村さん）
4. 緊急度・期限
5. 類似画面の DS突合表が既にあるか（`~/Desktop/GYS/` 配下）

## 🔴 守ること（過去のFBで固まった不変ルール）

- **レイアウト4点セット必須**: Header / Sidebar / Footer / Breadcrumb。実装側の import 構造に合わせる（島村さんFB 2026-05-19）
- **HTMLは `cp v0.N → v0.N+1` してから編集**（履歴を残す）
- **カラートークンは `reference/tailwind.config.js` が正本**（primary `#2295F9` / border `#cad2d9` / 入力エリア `#f5f7fa` 等）
- **画面基準 1366×768**、フォント Noto Sans JP
- **用語**: 「終了ボタン」→ **キャンセルボタン**、「閉じる」→ **×ボタン**（用語集 §3.1.5）
- **まず shared-components の既存コンポを使う**。Ignite UI は補完用
- **量産は同時3画面まで**（Figma MCPレート + context窓）
- L3/L5系のオープン質問は**画面横断で集約してから**業務側へ

## 参照先（キット外・リンクのみ）

| 種別 | 場所 |
|---|---|
| shared-components 本体 | `~/Desktop-backup/projects/gys-yosanhensei/gyousei-shared-components/src/components/` |
| 実装リポ | `~/Desktop-backup/projects/gys-yosanhensei/Yosanhensei-Frontend/` |
| デザインガイドライン v1.2 | Box ID `2176447218566` |
| 帳票仕様確認設計書フォルダ | Box ID `372679775768` |
| サンプルFigma（条件選択画面） | https://www.figma.com/design/WJV7kypIvgYuwLemNcEJPE |
| 現画面スクショ集（1,352件） | `~/Desktop/GYS/gys_bizbrouser_画面集/` |

作成: ファンリード 池田 ・ 2026-07-22
