# GYS 旧→新画面化 標準ワークフロー (量産ハンドオフ資料)

**版**: 1.0
**最終更新**: 2026-05-19
**ベースサンプル**: 対前年度比較表 (STD3290) / 予算査定一覧表(科目別) BFP9100
**対象読者**: ファンリード社 + AIエージェントチーム + その他協力者

---

## 1. 目的

旧システム (公営企業会計システム) の画面・帳票を、新システムのUIデザインガイドライン v1.2 に準拠した形に置換するため、**5フェーズの標準ワークフロー** を定義する。本資料は他チーム (人間+AIエージェント) が同じプロセスを再現できるよう書かれている。

サンプル成果物 (1画面ぶん):
- Figma: https://www.figma.com/design/WJV7kypIvgYuwLemNcEJPE
- HTMLプロト: `~/Desktop/GYS/prototype-condition-screen/index_v0.2.html`

---

## 2. ワークフロー全体像

```
[Box旧画面.xlsx] →┐
                  ① 抽出 (Phase 1)
                       ↓
                  ② DS突合 (Phase 2)  ←  [デザインガイドライン.docx]
                       ↓                  [shared-components リポ]
                  ③ プロトタイプ (Phase 3, HTML)
                       ↓
                  ④ Figma還元 (Phase 4)
                       ↓
                  ⑤ 実装引き継ぎ (Phase 5) → [Yosanhensei-Frontend へ]
```

### 所要時間目安 (1画面あたり)

| Phase | 内容 | 標準時間 |
|---|---|---|
| 1 | 旧画面項目抽出 | 30-60分 |
| 2 | デザインガイドライン照合 | 30-60分 |
| 3 | プロトタイプ作成 (HTML) | 60-90分 |
| 4 | Figma還元 | 30-60分 |
| 5 | 実装引き継ぎ | 30-60分 |
| **合計** | | **3-5時間/1画面** |

---

## 3. 必要な前提環境

### ツール
- **Claude Code CLI** (sonnet 4.6+ or opus 4.7)
- **MCP サーバー**:
  - `claude_ai_Box` (Box取得用)
  - `plugin_figma_figma` (Figma書込み)
- **インストール済みスキル** (~/.claude/skills/):
  - `prototype-to-figma` (alima-max/prototype-to-figma-skill)
  - `gys-old-to-new-screen` (本リポ同梱、後任Claude向け)
  - `frontend-design` (claude-plugins-official)
- ブラウザ (Chrome/Safari等)

### アクセス権
- Box: 「ぎょうせい/(ext)新会計システム」フォルダ閲覧権限
- Figma: Pro以上のアカウント (planKey 取得済み)
- GYS 共有Drive (Phase 2-5 ドキュメント保管)

### ローカル環境
- macOS / Linux
- `/Users/apple/Desktop-backup/projects/gys-yosanhensei/` (or 相当パス) に GYS モノレポをローカルclone
  - `gyousei-shared-components/`
  - `Yosanhensei-Frontend/`

---

## 4. 5フェーズ詳細

### Phase 1: 旧画面項目抽出

#### 入力
- Box ファイルID (帳表仕様確認書 .xlsx)
  - パス例: `ぎょうせい/(ext)新会計システム/30_設計/33_業務アプリ設計/帳票_仕様確認設計書/`
- 担当者: AI + 池田 (確認)

#### 手順
1. Box MCPで `get_file_details(file_id=...)` → ファイル種別とパス確認
2. `get_file_content(file_id=...)` → テキスト本文取得 (markdown)
3. `get_preview_page(fileId=..., page=N)` → 仕様書プレビュー画像取得
4. 画像が preview API で取れない場合:
   - 池田 (or 担当者) に Box から .xlsx ローカルダウンロード依頼
   - `unzip -o <xlsx> 'xl/media/*'` で埋め込み image1-3.png 抽出
   - Read で画像確認 → 画面ビジュアル把握
5. 構造化抽出 → Markdown表で:
   - 画面ID / 帳表ID
   - ヘッダ情報 (自治体名・所属・担当者・作成日)
   - 条件入力項目 (各項目: ラベル / 種別 / プルダウン選択肢 / マスタ/トラン参照)
   - ボタン (印刷/クリア/終了 等)
   - 帳票項目 (印刷フォーマット側)
   - 既存テーブル参照
   - **オープン質問** (要確認 5件目安)

#### 出力
- `~/Desktop/GYS/YYYYMMDD_{画面ID}_{画面名}_旧システム抽出.md`

#### よくある落とし穴
- Excel本文 (テキスト) だけだとA列/B列の物理配置が不明 → image取得必須
- 「××マスタ」「xxxトラン」表記は曖昧 → 実テーブル名を関連設計書から確認
- `get_preview_page` で page 1 が empty error の場合あり (表紙画像が原因) → page 2-N で本文取得

---

### Phase 2: デザインガイドライン照合

#### 入力
- Phase 1 抽出物
- 新会計システム UIデザインガイドライン (Box ID `2176447218566`)
- shared-components リポ (`~/Desktop-backup/projects/gys-yosanhensei/gyousei-shared-components/src/components/`)

#### 手順
1. ガイドライン本文を Box MCPで `get_file_content` → 全文取得
2. `gyousei-shared-components/src/components/` を ls → 利用可能コンポ一覧
3. `gyousei-shared-components/tailwind.config.js` → カラートークン取得
4. 旧画面の各項目を新DSコンポにマッピング:
   - 種別判定: Select 6+項 → SelectBox / 5以下 → Radio / 数値+単位 → InputWithUnit / 数値+ステッパー → StepperWithUnit / コード+名称 → DualInputField
   - 命名規則照合: 旧「終了」→「キャンセル」等
5. 突合表作成 (Markdown):

```markdown
| 旧項目 | 旧種別 | 新DSコンポ | shared-componentsファイル | 補足 |
|---|---|---|---|---|
| 年度 | プルダウン | SelectBox | components/select/ | システム日付の年 |
| 補正回数 + 回 | プルダウン+ラベル | StepperWithUnit | (新規追加候補) | 数値+▲▼+回 |
```

6. 未収載パターン洗い出し (DS Drift候補) → 新規追加要望リスト
7. オープン質問 (L1-L5 目安) 列挙

#### 出力
- `~/Desktop/GYS/YYYYMMDD_{画面ID}_旧→新DS突合表.md`

#### 重要なリファレンス値

**カラートークン** (gyousei-shared-components/tailwind.config.js):
```
primary:       #2295F9   (Figma抽出メインブルー)
primary-light: #DBEBF5   (ヘッダー背景・アクションボタン)
primary-dark:  #1B6DB4   (ボーダー・フォーカス状態)
border:        #cad2d9   (shared-components 共通ボーダー)
bg-input:      #f5f7fa   (入力エリア §4.1.1)
bg-unit:       #EEEEEE   (InputWithUnit 単位部分)
bg-readonly:   #F8F7F7   (DualInputField readonly)
notice-bg:     #D3EEFF   (テーブル content-bg / 通知バー)
menu-bg:       #F1F9FF   (メニュー背景)
```

**フォント** (§3.1.3):
- Noto Sans JP (Regular 400/Medium 500/Bold 700/Black 900)
- 28px = 画面タイトル / 16-20px = 小見出し / 13-14px = 本文/フッター / 10px = メニュー補助

**画面基準**:
- 解像度: 1366×768 (§2.2)
- 入力エリア背景: グレー `#f5f7fa` (§4.1.1)
- ボタン高: 大46/中36/小26 (§3.2.17)
- 金額表示: 桁カンマ + 単位「円」(千円ではなく円) + 右揃え (§3.2.8)

**命名規則** (§3.1.5 用語集):
| 用語 | 意味 | 使用 |
|---|---|---|
| 印刷 | PDF表示 | ボタン名OK |
| 出力 | ローカルファイルDL (CSV等) | ボタン名OK |
| クリア | 入力空に | ボタン名OK |
| 一時保存 | 一時DBに保存 (本伝票化はしない) | ボタン名OK |
| 登録 | DBに本登録 | ボタン名OK |
| キャンセル | 操作中止 (登録/OKと対) | ボタン名OK |
| 終了 | 用語集に未定義 → **使用しない** | ❌ |
| 閉じる | ボタン名ではなく ×ボタン | ❌ ボタン名NG |

---

### Phase 3: frontend-design でプロトタイプ作成

#### 入力
- Phase 1/2 の Markdown
- `frontend-design` skill

#### 🔴 必須レイアウト4点セット (島村さんFB 2026-05-19 反映)

実装側コードで以下4部品が必ず import されるため、Figma/HTMLプロトでも**必須**:

```jsx
import Header from '../../components/Header';
import Sidebar from '../../components/Sidebar';
import Footer from '../../components/Footer';
import Breadcrumb from '../../components/Breadcrumb';
```

| 部品 | 仕様 | 参考 |
|---|---|---|
| **Header** | 72h固定、ロゴ+操作年度+所属/担当者/ヘルプ | §3.2.1 |
| **Sidebar** | **280w固定**、background `#F1F9FF` (menu-bg)、15メニュー項目、現在地アクティブ+サブメニュー展開 | §3.2.3 + §4.1.1 |
| **Footer** | 56h程度、コピーライト+アクションボタン | §3.2.2 |
| **Breadcrumb** | Sidebar 下のMain領域内、「トップ › 親 › 現在地」 | §3.2.19 |

レイアウト構造:
```
Header (full-width 1366px)
├─ Sidebar (280w固定) ┬─ Main area (1086w = 1366-280)
│                     │   ├─ Breadcrumb
│                     │   ├─ Title + ID badge
│                     │   ├─ Tab
│                     │   └─ Content (検索エリア + アクション)
└─ ...                └─ ...
Footer (full-width 1366px)
```

#### 手順
1. `~/Desktop/GYS/prototype-{画面名}/` ディレクトリ作成
2. **単一HTMLファイル** (Tailwind CDN + Noto Sans JP via Google Fonts) を Write で生成
3. body は `<header>` → `<div class="flex flex-1"><aside>Sidebar</aside><div>Main</div></div>` → `<footer>` の構造
4. shared-components の **InputWithUnit / DualInputField / Button** パターンを CSS で再現
5. Sidebar には現在地アクティブ + サブメニュー5項目展開を表現
6. Ignite UI for React 移植マッピングを末尾コメントで明示
7. 要確認 (L3/L5等) を黄色ノートで画面内表示
8. ブラウザで `open` 確認
9. 池田・業務側で 1〜3 往復ブラッシュアップ

#### HTML スケルトン (転用可能)

```html
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+JP:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --gys-primary: #2295F9;
      --gys-primary-light: #DBEBF5;
      --gys-primary-dark: #1B6DB4;
      --gys-border: #cad2d9;
      --gys-bg-input: #f5f7fa;
      --gys-bg-unit: #EEEEEE;
      --gys-notice-bg: #D3EEFF;
    }
    body { font-family: 'Noto Sans JP', sans-serif; }
    /* InputWithUnit (shared-components/input-with-unit.tsx 準拠) */
    .gys-input-unit-wrap { display: inline-flex; align-items: stretch; border-radius: 4px; }
    .gys-input-unit-wrap > input { /* ... */ }
    .gys-input-unit-wrap > .unit-box { background: var(--gys-bg-unit); /* ... */ }
    /* DualInputField (shared-components/dual-input-field.tsx 準拠) */
    .gys-dual-input { /* ... */ }
    /* etc. */
  </style>
</head>
<body>
  <!-- Header / Breadcrumb / Title / Tab / Notice / 検索エリア / Footer -->
</body>
</html>
```

#### 出力
- `~/Desktop/GYS/prototype-{画面名}/index_v0.{N}.html`
- ブラウザで `open` 即動作確認可

#### 重要な落とし穴
- Tailwind CDN を使う場合 `<script src="https://cdn.tailwindcss.com">` のみで動く (Vite/npm不要)
- Google Fonts も link 1行で
- 各input/select は **shared-components 既存コンポ名 + クラス命名** を意識すると Phase 5 で楽
- Phase 4で読み込まれる前提なので、CSS変数は :root に明示的に書く

---

### Phase 4: prototype-to-figma で Figma還元

#### 入力
- Phase 3 の HTML
- `prototype-to-figma` skill

#### 手順
1. Skill ツールで `prototype-to-figma` 起動
2. スキル指示に従い:
   - `figma-create-new-file` MANDATORY skill load → `create_new_file(planKey=team::1316584710901923109, fileName="GYS {画面名} (画面ID) — Prototype", editorType="design")`
   - `figma-use` MANDATORY skill load → `use_figma` で建築
3. 通常 **7-9 use_figma call 分割** (1 call = 10 logical operations以下):

| Call | 内容 |
|---|---|
| 1 | メインフレーム + Header |
| 2 | **bodyRow (HORIZONTAL) + Sidebar shell + Main area** ← Header と Footer の間に 4点セット構造 |
| 3 | **Sidebar 内 メニュー15項目 + サブメニュー** (Main 領域は別途) |
| 4 | Main: Breadcrumb + Title + Tab + Notice + 共通設定 |
| 5 | Main: A列セクション (または並列セクション) |
| 6 | Main: B列セクション + 処理概要 + アクション |
| 7 | Footer |
| 8 | Annotation付与 (Interaction青 / DS Drift橙) |
| 9 | Overview frame (右隣に別配置) |

🔴 **重要**: Header と Footer は full-width (1366px) で main 直下、間に bodyRow (HORIZONTAL: Sidebar 280w + Main 1086w) を配置すること。Breadcrumb は Main 領域 (Sidebar 下) の中。

4. 各 call で **先頭フォント load 必須** (state リセットされる)

```js
await Promise.all([
  figma.loadFontAsync({ family: "Noto Sans JP", style: "Regular" }),
  figma.loadFontAsync({ family: "Noto Sans JP", style: "Medium" }),
  figma.loadFontAsync({ family: "Noto Sans JP", style: "Bold" }),
]);
```

5. `get_screenshot` で検証

#### 出力
- Figma ファイル (https://www.figma.com/design/...)
- Overview frame (x=1700, y=200 推奨)

#### use_figma 重要ルール (繰り返しハマるポイント)
- フォント load は **call ごとに先頭で実行** (state reset)
- color は **0-1 range** (parseInt(.../255))
- auto-layout の HUG/FILL は **appendChild 後設定**
- annotations は配列代入 (1ノードに複数OK)
- node ID は call 間で確実に保持 (return で渡す)
- メインフレームは **(200, 200)** に配置 (0,0 避ける)

#### Annotation 規約
- **Interaction (青)**: 2-4個/frame、frame-level + state-advancing CTA + grouped controls
- **DS Drift (橙)**: 未収載パターン or shared-components ライブラリ未連携の primitive

---

### Phase 5: 開発引き継ぎ

#### 入力
- Phase 4 Figma URL
- 業務側 OK (L3/L5 確認後)

#### 手順
1. プロトHTML の「Ignite UI 移植マッピング」コメントを抜粋
2. shared-components から `import { InputWithUnit, DualInputField, Button } from '@gyosei-team/shared-components'` で利用パターン整理
3. Figma Code Connect で Figmaコンポ ↔ 実装コードの紐付け (オプション)
4. 開発リード (安部・石倉) と大塚さん (実装) へ引き渡し:
   - Figma URL
   - shared-components 既存コンポ利用表
   - **新規追加要望コンポ** (例: SectionCard / StepperWithUnit / 2カラム比較パターン)
   - DS Drift 一覧

#### 出力
- 引き渡し用Markdown (Chatwork or Box)

---

## 5. Box ファイルID 一覧 (リファレンス)

| 用途 | Box ID | 説明 |
|---|---|---|
| デザインガイドライン | `2176447218566` | 新会計システム_UIデザインガイドライン_第1.2版.docx (7.7MB) |
| 帳表_予算査定一覧科目別 (サンプル) | `2183630001029` | xlsx (908KB) |
| 帳票仕様確認設計書フォルダ | `372679775768` | 配下に予算編成等の帳票設計書多数 |

---

## 6. shared-components 主要コンポ一覧 (30+件)

```
gyousei-shared-components/src/components/
├── header/             ← ①Header
├── footer/             ← ⑫Footer
├── breadcrumb/         ← ②Breadcrumb
├── heading/            ← ③Title
├── button/             ← 3階層 (main/secondary/tertiary)
├── input/              ← 基本テキスト入力
├── select/             ← セレクトボックス
├── checkbox/           ← チェック
├── radio*/             ← ラジオ
├── input-with-unit/    ← input + 単位 (回/月/円等)
├── dual-input-field/   ← コード+名称 ペア入力
├── amount-field/       ← 金額入力 (桁カンマ+右揃え+円)
├── budget-field/       ← 予算入力
├── date-field/         ← 日付 + カレンダー
├── date-range-field/   ← 期間
├── form/, form-field/  ← フォームレイアウト
├── form-label-with-required/  ← 必須ラベル
├── card/               ← カード
├── badge/              ← バッジ
├── alert/              ← 通知バー
├── dialog/, modal/     ← モーダル
├── dropdown-menu/      ← ドロップダウン
├── collapsible-section/ ← アコーディオン
├── debtor-search-dialog/ ← 検索ダイアログ (子画面)
├── container/          ← レイアウトコンテナ
├── empty-state/        ← 空状態
└── error-boundary/     ← エラー境界
```

---

## 7. Ignite UI for React (Yosanhensei-Frontend のみ採用)

```json
"@infragistics/igniteui-react-core": "^19.5.2",
"@infragistics/igniteui-react-grids": "^19.6.0",
"@infragistics/igniteui-react-inputs": "^19.5.2",
"@infragistics/igniteui-react-layouts": "^19.5.2"
```

**移植マッピング**:

| プロト CSS | Ignite UI コンポ |
|---|---|
| `.gys-input` | `IgrInput` |
| `.gys-select` | `IgrSelect` / `IgrCombo` |
| `.gys-stepper` | `IgrNumberInput` (built-in spinner) |
| `<input type="radio">` | `IgrRadioGroup` + `IgrRadio` |
| `.gys-btn-main` | `IgrButton variant="contained" color="primary"` |
| `.gys-btn-secondary` | `IgrButton variant="outlined" color="primary"` |
| `.gys-btn-tertiary` | `IgrButton variant="flat"` |
| データグリッド | `IgrGrid` (igniteui-react-grids) |

ただし、**まず shared-components の既存コンポを使う** ことが基本。Ignite UI は shared-components で覆われていない高度な部品 (グリッド、複雑なinput) に限定推奨。

---

## 8. 量産時の注意点

1. **同時並行は 3画面まで** — Figma MCP のレート制限と context 窓を考慮
2. 同じ shared-components コンポを別画面で別解釈しないよう **DS突合表は共有Driveで一元管理**
3. オープン質問 (L3/L5系) は **画面横断で集約** してから業務側へ
4. Phase 4 Figma作成は Figmaの個人フォルダではなく **GYS共有プロジェクトフォルダ** に保存推奨 (planKey/projectId 指定)
5. Phase 3 のHTMLプロトは Git で履歴管理 (v0.1, v0.2... と命名 + 編集前 cp してから Edit)
6. 用語の一貫性: 「終了」→「キャンセル」等の命名変更は **画面横断で同じ判断** を貫く

---

## 9. 完了サンプル (リファレンス)

### 対前年度比較表 (STD3290) / 予算査定一覧表(科目別) BFP9100

- **HTML プロト**: `~/Desktop/GYS/prototype-condition-screen/index_v0.2.html`
- **Figma**: https://www.figma.com/design/WJV7kypIvgYuwLemNcEJPE
- **Phase別資料**:
  - Phase 1: `~/Desktop/GYS/20260519_予算査定一覧科目別_条件選択画面_旧システム抽出.md`
  - Phase 2: `~/Desktop/GYS/20260519_条件選択画面_旧→新DS突合表.md`
  - 共有用: `~/Desktop/GYS/20260519_条件選択画面_新システム化_レビュー依頼_枇杷木島村.md`

---

## 10. トラブルシューティング

| 症状 | 原因 | 対処 |
|---|---|---|
| Excel image取れない (`get_preview_page` empty error) | preview API の制約 | ローカルダウンロード + unzip `xl/media/*` |
| `use_figma` で `Cannot use unloaded font` | call ごとにフォントstate reset | 各 call 先頭で `loadFontAsync` Promise.all |
| `layoutSizingHorizontal = 'FILL'` エラー | appendChild 前に設定 | 必ず親 appendChild 後に設定 |
| Figma 色がおかしい | 0-255 範囲で渡している | 必ず `parseInt/255` で 0-1 範囲に |
| `node.annotations = [...]` で1個しか付かない | 配列に複数渡せば全部付く | 同ノードに Interaction + DS Drift 両方可 |
| プロト HTML が真っ白 | Tailwind CDN が読み込めていない | ネット接続/CDN URL確認 |
| Box MCP Exec で error | ファイル50MB超 | get_file_content では取れない、preview/local DL |

---

## 11. 改訂履歴

| 版 | 日付 | 改訂者 | 内容 |
|---|---|---|---|
| 1.0 | 2026-05-19 | 池田 (アップルリード東京) + Claude | 初版。対前年度比較表 (STD3290) サンプル完了を機に量産用標準化 |
| 1.1 | 2026-05-19 | 池田 + Claude | 島村さんFB反映: **「Header/Sidebar/Footer/Breadcrumb 4点セット必須」を Phase 3-4 に明記**。実装側コードのimport構造に合わせ、Figma/HTMLプロトでも Sidebar (§3.2.3, 280w, menu-bg) を必ず含める |

---

## 12. お問い合わせ

- ワークフロー全般: 池田克彦 (ikeda@applead.tokyo)
- 業務側Q&A: 島村さん
- 設計側Q&A: 安部さん・石倉さん
- 実装側Q&A: 大塚さん

---

**Appendix: 後任Claude (AIエージェント) 向け**

このワークフローは `~/.claude/skills/gys-old-to-new-screen/` にスキル化されています。Claude Code セッションで「GYS の {画面名} を新システム化して」「対前年度比較表を新画面に」等のキーワードで自動発動します。
