/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      // z-index値を直接定義（tailwind-preset.tsと同期）
      zIndex: {
        'sidebar': '1',
        'header': '40',
        'footer': '40',
        'content': '1000',
        'modal-overlay': '9000',
        'modal': '9001',
        'modal-content': '9010',
      },
      colors: {
        // shadcn/ui標準カラー
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",

        // Figmaから抽出したプライマリカラー
        primary: {
          DEFAULT: '#2295F9',      // メインブルー
          light: '#DBEBF5',        // ヘッダー背景、アクションボタン
          dark: '#1B6DB4',         // ボーダー、フォーカス状態
          foreground: "hsl(var(--primary-foreground))",
          50: '#F1F9FF',
          100: '#DBEBF5',
          200: '#B8D5E7',
          300: '#99D2F5',
          600: '#2295F9',
          700: '#1B6DB4',
          900: '#1e40af'
        },

        // テーブルヘッダー専用カラー
        table: {
          'header-blue': '#99D2F5',
          'header-light': '#B8D5E7',
          'content-bg': '#D3EEFF'
        },

        // メニュー・背景
        menu: {
          background: '#F1F9FF'
        },

        // shadcn/ui標準カラー
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        secoundary: {
          DEFAULT: '#8C8989',
          light: '#EEEEEE',
          dark: '#595959',
        },
        tertiary: {
          DEFAULT: '#333333',
          light: '#CAD2D9',
          dark: '#595959',
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
      },
      spacing: {
        '96': '96px',        // 標準左パディング
        '280': '280px',      // メニュー固定幅
        '425': '425px',      // テーブル列幅1
        '129': '129px',      // テーブル列幅2
        '332': '332px',      // テーブル列幅3
        '346': '346px',      // テーブル列幅4
        '246': '246px',      // テーブル列幅5
      },
      boxShadow: {
        'menu': '2px 2px 10px rgba(0, 0, 0, 0.1)',
        'panel': '-4px 2px 8px rgba(0, 0, 0, 0.1)',
        'dropdown': '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        'menu-button': '0px 4px 4px 0px'  // 右側のみ角丸
      },
      fontFamily: {
        sans: ["Noto Sans JP", "sans-serif"],
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}
